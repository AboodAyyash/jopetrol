import 'package:flutter/material.dart';
import 'package:flutter_jo/profile.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      // debugShowMaterialGrid: false,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    print(_counter);
    setState(() {
      _counter++;
    });
    print(_counter);
  }

  String title = "Title";

  List numbers = [1, 23, 4, 56, 78, 4, 2, 24, 6, 7];

  TextEditingController nameCon = TextEditingController();
  TextEditingController passwordCon = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.purple,
        title: Text(title,
            style: const TextStyle(
              color: Color(0xFFFF0000),
            ) //Colors.white),
            ),
        actions: [
          IconButton(
            onPressed: () {
              print("HEllo");
            },
            icon: const Icon(
              Icons.settings,
              color: Colors.white,
              size: 35.0,
            ),
          ),
          InkWell(
            onTap: () {
              print("onTap");
            },
            onDoubleTap: () {
              print("onDoubleTap");
            },
            onLongPress: () {
              print("onLongPress");
            },
            child: Icon(
              Icons.search,
              color: Colors.white,
              size: 35.0,
            ),
          ),
        ],
      ),
      body: ListView(
        children: <Widget>[
          Container(
            margin: EdgeInsets.all(20),
            child: TextField(
              controller: nameCon,
              decoration: InputDecoration(
                labelText: "Name",
                hintText: "Enter Your name",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
                suffixIcon: Icon(Icons.arrow_forward_ios),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.all(20),
            child: TextField(
              controller: passwordCon,
              obscureText: true,
              decoration: InputDecoration(
                labelText: "Password",
                hintText: "Enter Your password",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
                suffixIcon: Icon(Icons.arrow_forward_ios),
              ),
              onChanged: (value) {
                print("onChange $value");
              },
              onTap: () {
                print("onTap");
              },
              onSubmitted: (value) {
                print("onSubmitted $value");
              },
              onEditingComplete: () {
                print("onEditingComplete ");
              },
            ),
          ),
          TextButton(
            onPressed: () {
              nameCon.text = "Ahmad";
              passwordCon.text = "123456";
            },
            child: Text("fill Data"),
          ),
          TextButton(
            onPressed: () {
              if (nameCon.text.isNotEmpty && passwordCon.text.isNotEmpty) {
                Navigator.push<void>(
                  context,
                  MaterialPageRoute<void>(
                    builder: (BuildContext context) => ProfilePage(
                      name: nameCon.text,
                      password: passwordCon.text,
                    ),
                  ),
                );
              }
            },
            child: Text("Login"),
          ),
          Text(
            '$_counter',
          ),
          Image.asset(
            "assets/images/logo.png",
            width: 50,
            height: 100,
            fit: BoxFit.cover,
          ),
          SizedBox(
            height: 20,
          ),
          Container(
            height: 120,
            child: ListView(
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              children: [
                for (int i = 0; i < numbers.length; i++)
                  Text(numbers[i].toString())
              ],
            ),
          ),
          Image.network(
            "https://www.simplilearn.com/ice9/free_resources_article_thumb/what_is_image_Processing.jpg",
            fit: BoxFit.cover,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _counter++;
          });
        },
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: Container(
        height: 60,
        color: Colors.blue,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Text("Text"),
            Text("Text"),
            Text("Text"),
            Text("Text"),
          ],
        ),
      ),
    );
  }
}
